MAS Leggings — Operations Dictionary: Feature Images
=====================================================

178 schematic images:
  - 146 covering every non-None value of the MAS dictionary snapshot
    (42 'None / No X' values intentionally skipped; 'Hem Stitch Finish -
    Flatlock' added because the source row has a missing value name)
  - 32 additional variants added on request (marked in manifest.csv notes),
    e.g. tack/bartack counts (x1-x7), side-seam tack positions, gusset
    liner tacks, Back Leg 2 Piece, Care Label Location - Waist,
    Inner Construction - Set to Mesh, Pre-tack Waistband to Body x4.

Folders
  png/<Category>/<Feature>__<Value>.png   web-ready images (2x resolution)
  svg/<Category>/<Feature>__<Value>.svg   editable vector masters
  manifest.csv                            per-image: category, feature, value,
                                          file, reworded title, caption,
                                          reference images used, notes
  index.html                              visual gallery (open in a browser)

Conventions
  Grey technical schematics + orange highlights, matching the Hem
  Circumference examples. Temporary tacks: discrete dashed bars drawn
  perpendicular to the seam at points (2 half points / 4 quarter points
  style), never a continuous run. Bartacks: dense solid bars. Counts shown
  as an xN badge. Rise images: arrow sits against the rise seam only, seam
  runs up to the waistband seam line.

Data notes (also in manifest.csv 'notes' column)
  - Hem Stitch Finish: the two source rows have swapped texts - the row
    named 'Coverstitch' carries the flatlock definition and the unnamed row
    carries the coverstitch definition. Images follow the value NAMES.
  - Reference style images used where clear: A-10232048, A-10340493,
    10330452, 10349903, 10242731, 10242732, 10242598, 10336981 and others
    (see manifest). A-10232047 / A-10234236 are photos too unclear to use.
